# EQUI_CONTROL — Aparato automatizado para mapeamento de superfícies equipotenciais

Máquina CNC de 2 eixos, controlada por Arduino e operada por aplicativo Android via
Bluetooth, que mapeia o potencial elétrico em uma cuba eletrolítica ponto a ponto e
desenha o mapa de calor em tempo real.

Desenvolvido como Trabalho de Conclusão de Curso no **IFAL — Campus Maceió**, com o
objetivo de comparar, em sala de aula, o mapeamento manual tradicional com a coleta
automatizada.

---

## O que este repositório contém

```
firmware/equi_control.ino     Firmware do Arduino Uno
app/EQUI_CONTROL.aia          Projeto do MIT App Inventor (importável)
docs/PROTOCOLO.md             Protocolo Bluetooth e formato dos dados
docs/CALIBRACAO.md            Como calibrar a máquina do zero
docs/HARDWARE.md              Lista de materiais e montagem
CHANGELOG.md                  Histórico de versões
```

---

## Hardware

| Item | Especificação |
|---|---|
| Controlador | Arduino Uno |
| Driver | CNC Shield V3 + A4988 |
| Eixos X/Y | Motores de passo NEMA 17 |
| Eixo Z | Servomotor com mecanismo complacente |
| Comunicação | Módulo Bluetooth HC-05 |
| Fim de curso | 4 sensores, em `INPUT_PULLUP` |
| Estrutura | MDF cortado a laser |
| Sensor | Divisor de tensão 1:5 na entrada analógica A2 |

Custo total de fabricação do protótipo: **R$ 843,91**.

Detalhes de montagem em [`docs/HARDWARE.md`](docs/HARDWARE.md).

---

## Como reproduzir

### 1. Firmware

Instale as bibliotecas `AccelStepper`, `Servo` e `SoftwareSerial` pela IDE do Arduino,
abra `firmware/equi_control.ino` e grave na placa.

**Antes de usar, calibre.** Os valores de área útil no início do arquivo são específicos
da máquina em que foi desenvolvido. Veja [`docs/CALIBRACAO.md`](docs/CALIBRACAO.md).

### 2. Aplicativo

1. Acesse [ai2.appinventor.mit.edu](http://ai2.appinventor.mit.edu)
2. `Projects → Import project (.aia)` e selecione `app/EQUI_CONTROL.aia`
3. Gere o APK por `Build → Android App (.apk)`

O aplicativo usa **telas virtuais**: um único `Screen` com dois painéis alternados
(Controle Manual e Varredura Automática). Isso é intencional — o `BluetoothClient` do
App Inventor não é compartilhado entre `Screens` diferentes, então usar duas telas reais
derrubaria a conexão a cada troca.

### 3. Operação

1. Ligue a máquina. O *homing* roda automaticamente e a ponta vai ao centro da cuba.
2. Pareie o HC-05 e conecte pelo aplicativo.
3. Use o Controle Manual para posicionar, e **Inserir Posição** para registrar um ponto.
4. Ou use a Varredura Automática para percorrer a área útil em ziguezague.
5. **Salvar Dados** grava um CSV em `/Documents/EQUI_<timestamp>.csv`.

---

## Formato dos dados

Cada linha do CSV registra um ponto medido:

```
X_mm,Y_mm,Tensao_V,Modo
0.00,0.00,2.44,manual
10.00,0.00,2.51,varredura
```

A coluna `Modo` distingue pontos inseridos manualmente dos coletados pela varredura,
permitindo comparar os dois métodos na análise.

A origem `(0,0)` é o **centro geométrico da cuba**, não o canto da máquina.

---

## Decisões de projeto que valem conhecer

**A leitura acontece com a ponta submersa.** O firmware guarda o valor lido durante a
imersão e envia esse valor, em vez de reler o sensor depois que o servo já levantou.

**O tempo de submersão é de 1000 ms.** Com tempos curtos a tensão ainda não estabilizou,
e as leituras saem quase idênticas entre pontos vizinhos — uma falsa impressão de
estabilidade que mascara o gradiente real do campo.

**O servo é desconectado antes da leitura.** O `detach` ocorre aos 500 ms e a medição aos
1000 ms, então o conversor analógico lê sem o ruído elétrico do PWM.

**Os laços de *homing* têm limite de passos.** Se um sensor falhar, a máquina para e
informa qual pino não respondeu, em vez de travar indefinidamente.

---

## Licença

Código e firmware sob **MIT**. Documentação e materiais didáticos sob
**CC BY-SA 4.0**. Veja [`LICENSE`](LICENSE).

Se você usar este trabalho, uma citação é bem-vinda:

```
SILVA, Anderson. Aparato experimental automatizado para o mapeamento de
superfícies equipotenciais. Trabalho de Conclusão de Curso — Instituto
Federal de Alagoas, Campus Maceió, 2026.
```
