# Histórico de versões

O formato segue, de modo aproximado, o [Keep a Changelog](https://keepachangelog.com/pt-BR/).

## [1.0.0]

Primeira versão consolidada, com firmware e aplicativo funcionais em conjunto.

### Firmware

- Varredura automática em ziguezague com máquina de estados não bloqueante
- Leitura da tensão feita **com a ponta submersa**, e não após o recolhimento
- Tempo de submersão de 1000 ms, para a tensão estabilizar antes da medida
- Servo desconectado antes da leitura, eliminando ruído de PWM no conversor A/D
- Controle do servo unificado: mesmo ângulo de imersão no modo manual e na varredura
- Coordenadas do aplicativo medidas a partir do centro da cuba
- Retorno automático ao centro ao concluir a varredura, com envio do sinal `FIM`
- Limite de passos nos laços de *homing*, com identificação do pino que falhou
- Terminador de linha `\n` puro, compatível com o delimitador do aplicativo
- Comando `M` para levantar a área útil, acessível pelo aplicativo
- Nomenclatura do eixo X: direita como `X_Max`, esquerda como `X_Min`

### Aplicativo

- Telas virtuais para Controle Manual e Varredura Automática, preservando a conexão
- Recepção por delimitador de linha, em vez de leitura por bytes disponíveis
- Acúmulo dos pontos e exportação em CSV com nome único por salvamento
- Coluna `Modo` distinguindo pontos manuais dos automáticos
- Contador de pontos que só incrementa quando a posição muda
- No modo manual, o ponto entra no mapa e no CSV apenas ao pressionar **Inserir Posição**
- Rótulo de status da varredura, com detecção automática de conclusão
