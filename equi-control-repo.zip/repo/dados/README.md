# Dados coletados

Esta pasta guarda os CSV exportados pelo aplicativo.

Por padrão os `.csv` estão no `.gitignore`, para não versionar dados brutos de campo
sem intenção. Se quiser publicar um conjunto específico — por exemplo, os dados usados
na análise do TCC — force a inclusão:

```bash
git add -f dados/coleta-2026-09-09.csv
```

Formato de cada arquivo:

```
X_mm,Y_mm,Tensao_V,Modo
```
