# Protocolo Bluetooth

Comunicação serial a **9600 bps** pelo HC-05. O Arduino aceita os mesmos comandos
pelo monitor serial, o que permite testar sem o aplicativo.

## Comandos (app → Arduino)

Um **único caractere** por comando. Caracteres extras são ignorados.

| Comando | Ação |
|---|---|
| `U` | Move em +Y, contínuo |
| `D` | Move em −Y, contínuo |
| `R` | Move em +X (direita), contínuo |
| `L` | Move em −X (esquerda), contínuo |
| `P` | Para todo movimento e aborta a varredura |
| `B` | Abaixa a ponta de prova |
| `S` | Levanta a ponta de prova |
| `V` | Inicia a varredura automática |
| `M` | Mapeia a área útil e imprime os limites no serial |

Os comandos direcionais são **contínuos**: o movimento segue até chegar um `P` ou até
um sensor de fim de curso ser acionado. No aplicativo, os botões enviam a direção no
`TouchDown` e o `P` no `TouchUp`.

## Telemetria (Arduino → app)

Uma linha por pacote, terminada em `\n` (apenas LF, sem CR):

```
X,Y,tensao
```

- `X` e `Y` em milímetros, a partir do centro da cuba
- `tensao` em volts, já convertida pelo divisor 1:5

O aplicativo lê com `DelimiterByte = 10` e `ReceiveText(-1)`, o que garante uma linha
completa por leitura. Ler por quantidade de bytes disponíveis fragmenta os pacotes e
perde pontos.

Em repouso, o Arduino envia telemetria a cada 1000 ms. Durante a varredura, envia um
pacote por ponto medido.

## Sinal de conclusão

Ao terminar a varredura, o Arduino envia:

```
FIM
```

A linha não tem vírgula, então a divisão por `,` no aplicativo devolve **um** item em
vez de três. O bloco que processa pontos exige três itens e a ignora automaticamente —
ela nunca é confundida com uma medição nem entra no CSV.
