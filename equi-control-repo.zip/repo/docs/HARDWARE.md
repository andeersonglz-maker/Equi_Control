# Hardware

## Lista de materiais

| Componente | Quantidade | Observação |
|---|---|---|
| Arduino Uno | 1 | |
| CNC Shield V3 | 1 | |
| Driver A4988 | 2 | eixos X e Y |
| Motor de passo NEMA 17 | 2 | |
| Servomotor | 1 | eixo Z, com mecanismo complacente |
| Módulo Bluetooth HC-05 | 1 | |
| Sensor de fim de curso | 4 | |
| Cuba eletrolítica | 1 | |
| Eletrodos | 2 | ver nota sobre corrosão |
| Estrutura em MDF | — | cortada a laser |

Custo total do protótipo: **R$ 843,91**.

## Ligações

| Função | Pino |
|---|---|
| Enable dos drivers | 8 |
| X STEP / DIR | 2 / 5 |
| Y STEP / DIR | 3 / 6 |
| Servo da ponta | 11 (Z+ na shield) |
| Fim de curso X_Max / X_Min | 9 / 12 |
| Fim de curso Y_Min / Y_Max | 10 / 13 |
| Sensor de tensão | A2 |
| Bluetooth RX / TX | A1 / A0 |

Os sensores de fim de curso usam `INPUT_PULLUP` e são considerados acionados em nível
lógico baixo.

## Nota sobre os eletrodos

Eletrodos de ferro ou aço comum **corroem rapidamente** em solução salina sob corrente
contínua, formando óxido alaranjado que se dispersa na água. Isso altera a condutividade
local, contamina a superfície dos eletrodos e pode enviesar as leituras em sessões longas.

Recomendações:

- Energize a célula apenas durante a coleta, nunca deixe ligada sem supervisão
- Prefira aço inoxidável ou grafite
- Troque a solução e limpe os eletrodos antes de cada sessão de medição, para que
  comparações entre coletas não sejam afetadas por resíduos
