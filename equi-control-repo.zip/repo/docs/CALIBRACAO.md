# Calibração

Os valores abaixo, no início de `firmware/equi_control.ino`, são **específicos da
máquina** onde o projeto foi desenvolvido. Refaça este procedimento na sua.

## 1. Verifique o referencial dos eixos

Convenção adotada:

| Sensor | Posição | Pino |
|---|---|---|
| `pinoX_Max` | Direita | 9 |
| `pinoX_Min` | Esquerda | 12 |
| `pinoY_Min` | Topo | 10 |
| `pinoY_Max` | Base | 13 |

Se a sua fiação diferir, ajuste apenas os números dos pinos. Confira movendo cada eixo
manualmente e observando qual sensor é acionado.

## 2. Levante a área útil

Com a máquina energizada e o *homing* concluído, envie `M` pelo aplicativo ou pelo
monitor serial. A máquina percorre os dois eixos até os limites opostos e imprime:

```
const long LIMITE_X_MAX = ####;
const long LIMITE_Y_MAX = ####;
```

Copie as duas linhas para o firmware, substituindo os valores existentes, e regrave.

Enquanto esses valores forem `0`, o comando `V` recusa iniciar a varredura e explica
o motivo — proteção contra varrer com limites inválidos.

## 3. Ache o centro da cuba

Posicione a ponta manualmente no centro geométrico da cuba, anote a posição em passos
e grave em `CENTRO_X` e `CENTRO_Y`. Esses valores definem a origem `(0,0)` exibida no
aplicativo. Se estiverem errados, o cursor aparece deslocado no mapa.

## 4. Ajuste o ângulo de imersão

`ANGULO_BAIXO` controla a profundidade da ponta. Ajuste até que ela toque a solução sem
forçar contra o fundo. Use o mesmo valor para o comando manual e para a varredura — se
diferirem, os dois métodos medem a profundidades distintas e a comparação fica viciada.

## 5. Confirme o fator de tensão

`FATOR_TENSAO` assume divisor resistivo 1:5 e referência de 5 V:

```
FATOR_TENSAO = (5.0 / 1023.0) * 5.0
```

Se o seu divisor tiver outra proporção, recalcule. Confira com um multímetro em pelo
menos dois pontos de tensão conhecida.

## Parâmetros da máquina de referência

| Constante | Valor | Significado |
|---|---|---|
| `PASSO_DESLOCAMENTO` | 200 | passos por incremento manual (5 mm) |
| `INCREMENTO_PASSO` | 400 | espaçamento entre pontos da varredura (10 mm) |
| `MARGEM_PASSOS` | 200 | folga das paredes da cuba (5 mm) |
| `TEMPO_DESCIDA` | 1000 ms | tempo submersa antes de medir |
| `DURACAO_SERVO` | 500 ms | tempo até o servo desconectar |
