/* =========================================================================
 *  CNC 2D para Mapeamento de Superficies Equipotenciais
 *  Arduino Uno + CNC Shield V3 + HC-05 + Servo (ponta de prova)
 *
 *  VERSAO CORRIGIDA. Alteracoes em relacao ao arquivo original estao
 *  marcadas com [FIX]. Os pontos que dependem de medida fisica da sua
 *  maquina estao marcados com [TODO].
 * ========================================================================= */

#include <AccelStepper.h>
#include <SoftwareSerial.h>
#include <Servo.h>

// ---------------------------------------------------------------------
//  MAPEAMENTO DE PINOS
// ---------------------------------------------------------------------
#define ENA_PIN 8
#define X_STEP  2
#define X_DIR   5
#define Y_STEP  3
#define Y_DIR   6

// [AJUSTE DO AUTOR] Referencial do eixo X: DIREITA = X_Max, ESQUERDA = X_Min.
// O sensor da direita continua no pino 9 e o da esquerda no 12; apenas os
// nomes foram trocados. Todas as verificacoes abaixo seguem apontando para
// os mesmos pinos fisicos de antes -- o comportamento nao muda.
const uint8_t pinoX_Max = 9;    // direita
const uint8_t pinoX_Min = 12;   // esquerda
const uint8_t pinoY_Min = 10;
const uint8_t pinoY_Max = 13;

const uint8_t pinoSensorTensao = A2;
const uint8_t pinoServo        = 11;   // Z+ na CNC Shield V3

SoftwareSerial bluetooth(A1, A0);      // (RX, TX)

AccelStepper motorX(1, X_STEP, X_DIR);
AccelStepper motorY(1, Y_STEP, Y_DIR);
Servo servoPonta;

// ---------------------------------------------------------------------
//  CONSTANTES DE OPERACAO
// ---------------------------------------------------------------------
const uint8_t ESTADO_ACIONADO = LOW;   // sensores em INPUT_PULLUP

const long  PASSO_DESLOCAMENTO = 200;  // 200 passos = 5 mm
const float PASSO_MM           = 5.0;
const float MM_POR_PASSO       = PASSO_MM / PASSO_DESLOCAMENTO;  // [FIX] 0.025

const unsigned long INTERVALO_TELEMETRIA = 1000UL;
const unsigned long DURACAO_SERVO        = 500UL;   // tempo ate o detach

const float FATOR_TENSAO = 0.024437;   // (5.0/1023.0) * 5.0  -> divisor 1:5

// [FIX] Angulo unificado. Antes o comando manual 'B' usava 75 e a varredura
// usava ANGULO_BAIXO=90, ou seja, a ponta mergulhava a profundidades
// diferentes conforme o modo. Ajuste este valor uma unica vez.
const int ANGULO_CIMA  = 0;
const int ANGULO_BAIXO = 85;

// [FIX] Formato do pacote de telemetria. Com 0, envia "X,Y,tensao" puro
// (numerico, pronto para split por virgula no App Inventor). Com 1, mantem
// o sufixo " V" do codigo original.
#define ENVIAR_SUFIXO_V 0

// ---------------------------------------------------------------------
//  ESTADO DO MOVIMENTO MANUAL (bitmask)
// ---------------------------------------------------------------------
const byte MOV_CIMA     = 0b0001;
const byte MOV_BAIXO    = 0b0010;
const byte MOV_DIREITA  = 0b0100;
const byte MOV_ESQUERDA = 0b1000;
byte estadoMovimento = 0;

unsigned long tempoUltimaLeitura = 0;

// Coordenadas logicas enviadas ao app, em mm
float appX = 0.0;
float appY = 0.0;

// ---------------------------------------------------------------------
//  MAQUINA DE ESTADOS DO SERVO (nao-bloqueante)
// ---------------------------------------------------------------------
bool          servoAtivo = false;
unsigned long tempoServo = 0;

// ---------------------------------------------------------------------
//  VARREDURA AUTOMATICA
// ---------------------------------------------------------------------
// [TODO] Rode o comando 'M' (mapearAreaUtil) e substitua os dois valores
// abaixo pelos numeros impressos no Serial Monitor. Enquanto forem 0, o
// comando 'V' recusa iniciar a varredura.
const long LIMITE_X_MAX = 4604;   // passos, sempre POSITIVO
const long LIMITE_Y_MAX = 10038;   // passos, sempre POSITIVO (usado como -Y)

// [FIX] Margem de seguranca para a ponta nao encostar na parede da cuba.
const long MARGEM_PASSOS = 200;

// [FIX] Centro geometrico da cuba, em passos. E a ORIGEM do sistema de
// coordenadas que o app exibe: no centro, o app mostra X=0 e Y=0.
const long CENTRO_X = 2323;    // positivo = esquerda
const long CENTRO_Y = -4740;   // negativo = baixo

const long INCREMENTO_PASSO = 400;   // 400 passos = 10 mm entre pontos

// [AJUSTE DO AUTOR] 1000 ms, nao 300. Com 300 a leitura era feita antes de a
// tensao no eletrodo estabilizar: os valores saiam quase identicos entre pontos
// vizinhos, o que dava uma falsa impressao de estabilidade.
// Observacao: DURACAO_SERVO continua em 500 ms, entao o servo faz o detach aos
// 500 ms e a leitura ocorre aos 1000 ms com o PWM desligado -- o ADC fica sem o
// ruido do servo. Foi nessa configuracao que a leitura se mostrou confiavel.
const unsigned long TEMPO_DESCIDA = 1000UL; // ms submersa antes de ler
const unsigned long TEMPO_SUBIDA  = 300UL;  // ms ate a ponta recolher
const unsigned long DELAY_APP     = 300UL;  // [FIX] era usado sem declarar

enum EstadoVarredura {
  PARADO,
  MOVENDO,
  AGUARDANDO_DESCIDA,
  AGUARDANDO_SUBIDA,
  ENVIANDO,
  AGUARDANDO_APP
};
EstadoVarredura estadoVarreduraAtual = PARADO;

bool varreduraAtiva = false;

// [FIX] Todas estas variaveis eram usadas em processarVarredura() sem
// nunca terem sido declaradas - era o motivo de o sketch nao compilar.
long passoAtualX = 0;
long passoAtualY = 0;
int  direcaoX    = 1;            // 1 = zigue, -1 = zague
int  valorLeitura = 0;           // leitura RAW feita com a ponta submersa
unsigned long tempoVarredura = 0;  // [FIX] separado de tempoServo
unsigned long tempoEnvio     = 0;

// [FIX] Trava dos loops de homing. Sem isto, um sensor com defeito
// congelava o Arduino para sempre, sem nenhuma mensagem.
const long MAX_PASSOS_HOMING = 60000;

// ---------------------------------------------------------------------
//  PROTOTIPOS
//  A IDE do Arduino costuma gera-los sozinha, mas declarar explicitamente
//  evita erros de "not declared in this scope" em versoes mais antigas.
// ---------------------------------------------------------------------
bool quinaAtingida(uint8_t pino);
bool buscarSensor(AccelStepper &motor, uint8_t pino, long alvo);
void executarHomingOficial();
void mapearAreaUtil();
void posicionarNoCentro();
void atualizarCoordenadasApp();
void enviarPacote(float x, float y, int leituraRaw);
void enviarTelemetria();
void acionarServo(int angulo);
void atualizarServo();
void interpretarComando(char comando);
void processarComandos();
void processarEixoX();
void processarEixoY();
void processarTelemetriaRotina();
void iniciarVarredura();
void finalizarVarredura();
void processarVarredura();

// =====================================================================
//  SETUP
// =====================================================================
void setup() {
  Serial.begin(9600);
  bluetooth.begin(9600);

  pinMode(ENA_PIN, OUTPUT);
  digitalWrite(ENA_PIN, LOW);

  pinMode(pinoX_Min, INPUT_PULLUP);
  pinMode(pinoX_Max, INPUT_PULLUP);
  pinMode(pinoY_Min, INPUT_PULLUP);
  pinMode(pinoY_Max, INPUT_PULLUP);
  pinMode(pinoSensorTensao, INPUT);

  // write antes do attach: evita o pulso de 90 graus na energizacao
  servoPonta.write(ANGULO_CIMA);
  servoPonta.attach(pinoServo);
  delay(500);
  servoPonta.detach();

  motorX.setMaxSpeed(900.0);
  motorX.setAcceleration(600.0);
  motorY.setMaxSpeed(900.0);
  motorY.setAcceleration(600.0);

  executarHomingOficial();
  posicionarNoCentro();

  Serial.println(F("Comandos: U D R L (mover) | P (parar) | B S (ponta)"));
  Serial.println(F("          V (varredura)   | M (mapear area util)"));
}

// =====================================================================
//  SENSORES
// =====================================================================
bool quinaAtingida(uint8_t pino) {
  return (digitalRead(pino) == ESTADO_ACIONADO);
}

// [FIX] Homing com limite de passos. Retorna false se o sensor nao
// respondeu dentro do curso esperado.
bool buscarSensor(AccelStepper &motor, uint8_t pino, long alvo) {
  long partida = motor.currentPosition();
  motor.moveTo(alvo);
  while (!quinaAtingida(pino)) {
    motor.run();
    if (abs(motor.currentPosition() - partida) > MAX_PASSOS_HOMING) {
      motor.stop();
      Serial.print(F("FALHA: sensor no pino "));
      Serial.print(pino);
      Serial.println(F(" nao respondeu. Verifique a fiacao."));
      return false;
    }
  }
  motor.stop();
  return true;
}

// =====================================================================
//  HOMING
// =====================================================================
void executarHomingOficial() {
  Serial.println(F("=== INICIANDO CICLO DE HOMING ==="));

  motorX.setMaxSpeed(800.0);
  motorY.setMaxSpeed(800.0);

  // ----- EIXO X: busca o sensor X-Min -----
  Serial.println(F("Movendo X (buscando X-Max, a direita)..."));
  if (!buscarSensor(motorX, pinoX_Max, -30000)) return;
  delay(200);

  motorX.setCurrentPosition(0);
  motorX.runToNewPosition(250);        // recuo
  delay(200);

  motorX.setMaxSpeed(100.0);           // busca fina
  if (!buscarSensor(motorX, pinoX_Max, -500)) return;

  motorX.setCurrentPosition(0);
  motorX.setMaxSpeed(300.0);
  motorX.runToNewPosition(100);
  motorX.setCurrentPosition(0);

  // ----- EIXO Y: busca o sensor Y-Min -----
  Serial.println(F("Movendo Y (buscando Y-Min)..."));
  motorY.setMaxSpeed(300.0);
  if (!buscarSensor(motorY, pinoY_Min, 30000)) return;
  delay(200);

  motorY.setCurrentPosition(0);
  motorY.runToNewPosition(-250);
  delay(200);

  motorY.setMaxSpeed(100.0);
  if (!buscarSensor(motorY, pinoY_Min, 500)) return;

  motorY.setCurrentPosition(0);
  motorY.setMaxSpeed(300.0);
  motorY.runToNewPosition(-100);
  motorY.setCurrentPosition(0);

  motorX.setMaxSpeed(900.0);
  motorY.setMaxSpeed(900.0);

  Serial.println(F("=== MAQUINA CALIBRADA ==="));
  Serial.println(F("Origem no canto superior direito (X_Max / Y_Min)."));
}

// =====================================================================
//  MAPEAMENTO DA AREA UTIL
// =====================================================================
void mapearAreaUtil() {
  Serial.println(F("=== MAPEAMENTO DE AREA UTIL ==="));

  Serial.println(F("Buscando X-Min (a esquerda)..."));
  motorX.setMaxSpeed(400.0);
  if (!buscarSensor(motorX, pinoX_Min, 50000)) return;
  long passosMaxX = abs(motorX.currentPosition());

  motorX.setMaxSpeed(900.0);
  motorX.runToNewPosition(0);

  Serial.println(F("Buscando Y-Max..."));
  motorY.setMaxSpeed(400.0);
  if (!buscarSensor(motorY, pinoY_Max, -50000)) return;
  long passosMaxY = abs(motorY.currentPosition());

  motorY.setMaxSpeed(900.0);
  motorY.runToNewPosition(0);

  Serial.println(F("--- COPIE OS VALORES ABAIXO PARA O CODIGO ---"));
  Serial.print(F("const long LIMITE_X_MAX = "));
  Serial.print(passosMaxX);
  Serial.println(F(";"));
  Serial.print(F("const long LIMITE_Y_MAX = "));
  Serial.print(passosMaxY);
  Serial.println(F(";"));
  Serial.println(F("--------------------------------------------"));

  posicionarNoCentro();
}

// =====================================================================
//  POSICIONAMENTO
// =====================================================================
void posicionarNoCentro() {
  Serial.println(F("=== DESLOCANDO PARA O CENTRO DA CUBA ==="));

  servoPonta.write(ANGULO_CIMA);
  servoPonta.attach(pinoServo);
  delay(500);
  servoPonta.detach();

  motorX.setMaxSpeed(600.0);
  motorY.setMaxSpeed(600.0);

  motorX.moveTo(CENTRO_X);
  motorY.moveTo(CENTRO_Y);

  while (motorX.distanceToGo() != 0 || motorY.distanceToGo() != 0) {
    motorX.run();
    motorY.run();
  }

  motorX.setMaxSpeed(900.0);
  motorY.setMaxSpeed(900.0);

  // [FIX] mantem as coordenadas logicas coerentes com a posicao fisica
  atualizarCoordenadasApp();

  Serial.println(F("Ponta de prova no centro geometrico."));
}

// [FIX] Converte a posicao real dos motores para as coordenadas em mm
// que o app exibe, respeitando a convencao de sinais do projeto.
void atualizarCoordenadasApp() {
  // [FIX] Medido a partir do CENTRO da cuba, nao da origem do homing (canto).
  // Antes disto, ao centralizar a maquina o app recebia X=-58 / Y=118 e
  // desenhava o cursor no canto superior esquerdo do Canvas.
  appX = -(motorX.currentPosition() - CENTRO_X) * MM_POR_PASSO;
  appY = -(motorY.currentPosition() - CENTRO_Y) * MM_POR_PASSO;
}

// =====================================================================
//  TELEMETRIA
// =====================================================================
// [FIX] Agora recebe a leitura RAW como parametro. Isso permite enviar o
// valor medido COM A PONTA SUBMERSA, em vez de reler o sensor depois que
// o servo ja levantou - que era o comportamento do codigo original.
void enviarPacote(float x, float y, int leituraRaw) {
  float tensaoReal = leituraRaw * FATOR_TENSAO;

  bluetooth.print(x);
  bluetooth.print(F(","));
  bluetooth.print(y);
  bluetooth.print(F(","));
#if ENVIAR_SUFIXO_V
  bluetooth.print(tensaoReal);
  bluetooth.print(F(" V"));
#else
  bluetooth.print(tensaoReal);
#endif
  // [FIX] Apenas '\n', sem o '\r' que o println() acrescenta. O App Inventor
  // le com DelimiterByte=10; um '\r' extra ficaria colado no valor da tensao.
  bluetooth.print('\n');
}

void enviarTelemetria() {
  enviarPacote(appX, appY, analogRead(pinoSensorTensao));
}

// =====================================================================
//  SERVO
// =====================================================================
void acionarServo(int angulo) {
  servoPonta.write(angulo);        // define o angulo ANTES de liberar o PWM
  servoPonta.attach(pinoServo);
  tempoServo = millis();
  servoAtivo = true;
}

void atualizarServo() {
  if (servoAtivo && (millis() - tempoServo >= DURACAO_SERVO)) {
    servoPonta.detach();
    servoAtivo = false;
  }
}

// =====================================================================
//  COMANDOS
// =====================================================================
void interpretarComando(char comando) {
  switch (comando) {
    case 'U': estadoMovimento |= MOV_CIMA;     break;
    case 'D': estadoMovimento |= MOV_BAIXO;    break;
    case 'R': estadoMovimento |= MOV_DIREITA;  break;
    case 'L': estadoMovimento |= MOV_ESQUERDA; break;

    case 'P':
      estadoMovimento = 0;
      if (varreduraAtiva) {
        acionarServo(ANGULO_CIMA);
        varreduraAtiva = false;
        // [FIX] sem isto, um 'V' posterior retomava no meio do estado
        // anterior em vez de comecar do zero
        estadoVarreduraAtual = PARADO;
        Serial.println(F("Varredura abortada pelo usuario."));
      }
      break;

    case 'V':
      iniciarVarredura();
      break;

    case 'M':
      mapearAreaUtil();
      break;

    case 'B': acionarServo(ANGULO_BAIXO); break;
    case 'S': acionarServo(ANGULO_CIMA);  break;
  }
}

void processarComandos() {
  if (bluetooth.available() > 0) interpretarComando(bluetooth.read());
  if (Serial.available()    > 0) interpretarComando(Serial.read());
}

// =====================================================================
//  MOVIMENTO MANUAL
// =====================================================================
void processarEixoY() {
  if (motorY.distanceToGo() != 0) return;

  if (estadoMovimento & MOV_CIMA) {
    if (!quinaAtingida(pinoY_Max)) {
      motorY.move(-PASSO_DESLOCAMENTO);
      appY += PASSO_MM;
      enviarTelemetria();
    } else {
      estadoMovimento &= ~MOV_CIMA;
      Serial.println(F("ALERTA: limite Y-Max atingido."));
    }
  }
  else if (estadoMovimento & MOV_BAIXO) {
    if (!quinaAtingida(pinoY_Min)) {
      motorY.move(PASSO_DESLOCAMENTO);
      appY -= PASSO_MM;
      enviarTelemetria();
    } else {
      estadoMovimento &= ~MOV_BAIXO;
      Serial.println(F("ALERTA: limite Y-Min atingido."));
    }
  }
}

void processarEixoX() {
  if (motorX.distanceToGo() != 0) return;

  if (estadoMovimento & MOV_DIREITA) {
    if (!quinaAtingida(pinoX_Max)) {
      motorX.move(-PASSO_DESLOCAMENTO);
      appX += PASSO_MM;
      enviarTelemetria();
    } else {
      estadoMovimento &= ~MOV_DIREITA;
      Serial.println(F("ALERTA: limite X-Max (direita) atingido."));
    }
  }
  else if (estadoMovimento & MOV_ESQUERDA) {
    if (!quinaAtingida(pinoX_Min)) {
      motorX.move(PASSO_DESLOCAMENTO);
      appX -= PASSO_MM;
      enviarTelemetria();
    } else {
      estadoMovimento &= ~MOV_ESQUERDA;
      Serial.println(F("ALERTA: limite X-Min (esquerda) atingido."));
    }
  }
}

void processarTelemetriaRotina() {
  if (millis() - tempoUltimaLeitura >= INTERVALO_TELEMETRIA) {
    tempoUltimaLeitura = millis();
    if (motorX.distanceToGo() == 0 && motorY.distanceToGo() == 0 &&
        estadoMovimento == 0 && !varreduraAtiva) {
      enviarTelemetria();
    }
  }
}

// =====================================================================
//  VARREDURA AUTOMATICA EM ZIGUEZAGUE
// =====================================================================
void iniciarVarredura() {
  if (LIMITE_X_MAX == 0 || LIMITE_Y_MAX == 0) {
    Serial.println(F("ERRO: area util nao definida."));
    Serial.println(F("Rode o comando 'M' e preencha LIMITE_X_MAX/Y_MAX."));
    return;
  }

  estadoMovimento = 0;
  varreduraAtiva  = true;
  direcaoX        = 1;

  // [FIX] a varredura original partia de (0,0) sem nunca ir ate la,
  // fazendo a maquina saltar do centro para o canto no primeiro ponto
  passoAtualX = MARGEM_PASSOS;
  passoAtualY = -MARGEM_PASSOS;

  motorX.moveTo(passoAtualX);
  motorY.moveTo(passoAtualY);
  atualizarCoordenadasApp();

  estadoVarreduraAtual = MOVENDO;
  Serial.println(F("=== VARREDURA AUTOMATICA INICIADA ==="));
}

void finalizarVarredura() {
  acionarServo(ANGULO_CIMA);
  varreduraAtiva = false;
  estadoVarreduraAtual = PARADO;

  // [AJUSTE DO AUTOR] devolve a ponta ao centro da cuba ao terminar.
  delay(DURACAO_SERVO);   // espera a ponta subir antes de deslocar em XY
  atualizarServo();       // executa o detach pendente do servo
  posicionarNoCentro();

  // [AJUSTE DO AUTOR] avisa o app que a varredura acabou. E uma linha SEM
  // virgula: o split do App Inventor devolve 1 item em vez de 3, entao ela
  // nunca e confundida com um ponto de medicao nem entra no CSV.
  bluetooth.print(F("FIM"));
  bluetooth.print('\n');

  enviarTelemetria();     // primeira telemetria ja no centro (0,0)
  Serial.println(F("=== VARREDURA CONCLUIDA ==="));
}

void processarVarredura() {
  if (!varreduraAtiva) return;

  switch (estadoVarreduraAtual) {

    case PARADO:
      break;

    case MOVENDO:
      if (motorX.distanceToGo() == 0 && motorY.distanceToGo() == 0) {
        atualizarCoordenadasApp();
        acionarServo(ANGULO_BAIXO);   // [FIX] era meuServo.write(), sem attach
        tempoVarredura = millis();
        estadoVarreduraAtual = AGUARDANDO_DESCIDA;
      }
      break;

    case AGUARDANDO_DESCIDA:
      if (millis() - tempoVarredura >= TEMPO_DESCIDA) {
        analogRead(pinoSensorTensao);               // descarte do ADC
        valorLeitura = analogRead(pinoSensorTensao); // leitura COM a ponta na agua

        acionarServo(ANGULO_CIMA);
        tempoVarredura = millis();
        estadoVarreduraAtual = AGUARDANDO_SUBIDA;
      }
      break;

    case AGUARDANDO_SUBIDA:
      if (millis() - tempoVarredura >= TEMPO_SUBIDA) {
        estadoVarreduraAtual = ENVIANDO;
      }
      break;

    case ENVIANDO:
      // [FIX] envia o valor medido submerso, nao uma releitura fora da agua
      enviarPacote(appX, appY, valorLeitura);
      Serial.print(appX); Serial.print(F(", "));
      Serial.print(appY); Serial.print(F(", RAW "));
      Serial.println(valorLeitura);

      tempoEnvio = millis();
      estadoVarreduraAtual = AGUARDANDO_APP;
      break;

    case AGUARDANDO_APP:
      if (millis() - tempoEnvio > DELAY_APP) {
        passoAtualX += (INCREMENTO_PASSO * direcaoX);

        if (passoAtualX >= LIMITE_X_MAX - MARGEM_PASSOS) {
          passoAtualX = LIMITE_X_MAX - MARGEM_PASSOS;
          direcaoX    = -1;
          passoAtualY -= INCREMENTO_PASSO;
        }
        else if (passoAtualX <= MARGEM_PASSOS) {
          passoAtualX = MARGEM_PASSOS;
          direcaoX    = 1;
          passoAtualY -= INCREMENTO_PASSO;
        }

        if (passoAtualY <= -(LIMITE_Y_MAX - MARGEM_PASSOS)) {
          finalizarVarredura();
          return;
        }

        motorX.moveTo(passoAtualX);
        motorY.moveTo(passoAtualY);
        estadoVarreduraAtual = MOVENDO;
      }
      break;
  }
}

// =====================================================================
//  LOOP
// =====================================================================
void loop() {
  processarComandos();

  // [FIX] o movimento manual fica bloqueado enquanto a varredura roda,
  // para os dois nao disputarem o mesmo motor
  if (!varreduraAtiva) {
    processarEixoY();
    processarEixoX();
  }

  motorX.run();
  motorY.run();

  atualizarServo();
  processarTelemetriaRotina();
  processarVarredura();
}
